#!/bin/bash

cd "/home/dw16/Desktop/v2rayLOVE-20250402"
python3 1.py

