#!/bin/bash

cd "/home/dw16/Desktop/v2rayLOVE-20230910"
python3 1.py

